var express = require('express');

var router = express.Router();

var database = require('../database');

router.get("/", function(request, response, next){

	var query = "SELECT * FROM child ORDER BY id DESC";

	database.query(query, function(error, data){

		if(error)
		{
			throw error; 
		}
		else
		{
			response.render('sample_data', {title:'Node.js MySQL CRUD Application', action:'list', child:data});
		}

	});

});

router.get("/add",function(request,response,next){
	response.render("sample_data",{title:'Inset Data into MySQL', action:'add'});
});
router.post("/add_sample_data",function(request,response,next){
	var firstName = request.body.firstName;
	var lastName = request.body.lastName;
	var age = request.body.age;
	var gender = request.body.gender;
	var fishCaught = request.body.fishCaught;
	/*
	INSERT INTO `child` (`id`, `firstName`, `lastName`, `fishCaught`, 
	`age`, `gender`) VALUES ('8755', 'fish', 'fishy', '7', '67', 
	'Male');
	*/

	var query = `
	INSERT INTO child
	(firstName, lastName, fishCaught, age, gender) 
	VALUES ("${firstName}", "${lastName}", "${fishCaught}", "${age}", "${gender}")
	`;

	database.query(query,function(error,data){
		if(error)
		{
			throw error;
		}
		else{
			response.redirect("/")
		}
	})

});

router.get('/:id',function(request, response, next){
	var id = request.params.id;
	var query = `SELECT * FROM child WHERE id = "${id}"`;

	database.query(query, function(error, data){

		response.render('sample_data', {title: 'Edit MySQL Table Data', action:'edit', sampleData:data[0]});
	});
})

router.post('/:id', function(request,response,next){
	var id = request.params.id;
	var firstName = request.body.firstName;
	var lastName =request.body.lastName;
	var age = request.body.age;
	var gender = request.body.gender;
	var fishCaught = request.body.fishCaught

	var query = `
	UPDATE child
	SET firstName = "${firstName}", 
	lastName = "${lastName}", 
	age = "${age}", 
	gender = "${gender}",
	fishCaught ="${fishCaught}"
	WHERE id = "${id}"`;
	database.query(query, function(error, data){

		if(error)
		{
			throw error;
		}
		else{
			response.redirect("/")
		}
	});
});
router.get("/delete/:id",function(request,response,next){
	var id = request.params.id;
	var query = `DELETE FROM child WHERE id = "${id}"`;
	database.query(query, function(error, data){

		if(error)
		{
			throw error;
		}
		else{
			response.redirect("/")
		}
	});
})	
module.exports = router;