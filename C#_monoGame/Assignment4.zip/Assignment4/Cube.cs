﻿using Microsoft.Xna.Framework;
using SharpDX.XAudio2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4
{
    

    public class Cube
    {
       
        public Vector3 position;
        public float scale;
        public Color color;
        public Vector3 velocity;

        public Cube(Color color,Vector3 position,float scale,Vector3 volocity) {
            this.color = color;
            this.position = position;
            this.scale = scale;
            this.velocity = volocity;
        }
        
    }
}
