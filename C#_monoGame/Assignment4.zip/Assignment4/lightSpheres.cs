﻿using Microsoft.Xna.Framework;


namespace Assignment4
{
    struct Light
    {
        
    }

    public class lightSpheres
    {
        public Vector3 position;
        public Color color;
        public Vector3 velocity;

        public lightSpheres(Vector3 position,Vector3 velocity, Color color)
        {
            this.position = position;
            this.velocity = velocity;
            this.color = color;
        }

    }
}
