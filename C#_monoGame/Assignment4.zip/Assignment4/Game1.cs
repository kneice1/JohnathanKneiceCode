﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using SharpDX.MediaFoundation;
using System;
using System.Collections.Generic;

namespace Assignment4
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager graphics;
        private SpriteBatch _spriteBatch;
        List<Cube> cubes;
        List<lightSpheres> spheres;
        private Effect cubeEffect;
        Model model;
        Model ball;
        BasicEffect effect;
        private TextureCube cubeTexture;
        private Effect skyBoxEffect;
        VertexBuffer vertex;
        Vector3 cameraPosition = new Vector3(0, 0, 0);
        float yaw = 0.0f;
        float pitch = 0.0f;


        Matrix world = Matrix.CreateTranslation(0, 0, 0);
        Matrix view =Matrix.CreateLookAt(new Vector3(0, 0, 7), new Vector3(0, 0, 0),Vector3.UnitY);
        Matrix projection;
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
            graphics.GraphicsProfile = GraphicsProfile.HiDef;
        }

        protected override void Initialize()
        {
            
            base.Initialize();
        }

        protected override void LoadContent()
        {
            effect = new BasicEffect(GraphicsDevice);
            model = Content.Load<Model>("cube");
            cubeTexture = Content.Load<TextureCube>("Ocean");
            skyBoxEffect = Content.Load<Effect>("skybox");
            ball = Content.Load<Model>("sphere");
            _spriteBatch = new SpriteBatch(GraphicsDevice);
            projection = Matrix.CreatePerspectiveFieldOfView(MathHelper.ToRadians(90), GraphicsDevice.Viewport.AspectRatio, 0.1f, 1000f);
            cubes = new List<Cube>();
            spheres = new List<lightSpheres>();
            
            cubeEffect = Content.Load<Effect>("cubeShader");
            for (int i = 0; i < 80; i++) {
                
                cubes.Add(CubeSetter());
            }

            for (int i = 0; i < 3; i++) { 
                spheres.Add(SphereSetter());
            }

            // TODO: use this.Content to load your game content here
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();
           float x = 0f;
           float z = 0f;

            KeyboardState state = Keyboard.GetState();
            if (state.IsKeyDown(Keys.Down))
            {
                pitch -= .01f;
            }
            if (state.IsKeyDown(Keys.Up))
            {
                pitch += .01f;
            }
            if (state.IsKeyDown(Keys.Left))
            {
                yaw += .01f;
            }
            if (state.IsKeyDown(Keys.Right))
            {
                yaw -= .01f;
            }
            if (state.IsKeyDown(Keys.W))
            {
                z += 1f;
            }
            if (state.IsKeyDown(Keys.S))
            {
                z -= 1f;
            }
            if (state.IsKeyDown(Keys.D))
            {
                x += 1f;
            }
            if (state.IsKeyDown(Keys.A))
            {
                x -= 1f;
            }
            Matrix matrix = Matrix.CreateFromYawPitchRoll(yaw, pitch, 0);

            Vector3 forward = -Vector3.UnitZ;
            Vector3 right = Vector3.UnitX;
            Vector3 up = Vector3.UnitY;
            forward = Vector3.Transform(forward, matrix);
            up = Vector3.Transform(up, matrix);
            right = Vector3.Transform(right, matrix);
            cameraPosition += right * x + z * forward;
            view = Matrix.CreateLookAt(cameraPosition, cameraPosition + forward, up);
           

            //update positions

            float time=gameTime.ElapsedGameTime.Milliseconds / 1000.0f;
            foreach (Cube cube in cubes)
            {
                
                cube.position += cube.velocity * time;
                if (cube.position.Y > (90 - cube.scale) || cube.position.Y < (-90 + cube.scale)){ cube.velocity.Y *= -1; }
                if (cube.position.X > (90 - cube.scale) || cube.position.X < (-90 + cube.scale)) { cube.velocity.X *= -1; }
                if (cube.position.Z > (90 - cube.scale) || cube.position.Z < (-90 + cube.scale)) { cube.velocity.Z *= -1; }
            }
            foreach (lightSpheres sphere in spheres)
            {
                sphere.position += sphere.velocity*time;
                if (sphere.position.Y > (80) || sphere.position.Y < (-80)) { sphere.velocity.Y *= -1; }
                if (sphere.position.X > (80) || sphere.position.X < (-80)) { sphere.velocity.X *= -1; }
                if (sphere.position.Z > (80) || sphere.position.Z < (-80)) { sphere.velocity.Z *= -1; }
                
            }

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            world = Matrix.CreateScale(300f) * Matrix.CreateTranslation(cameraPosition);
            GraphicsDevice.Clear(Color.CornflowerBlue);
            RasterizerState state = new RasterizerState();
            state.CullMode= CullMode.None;
            GraphicsDevice.RasterizerState = state;
            
                foreach (ModelMesh mesh in model.Meshes) {
                    foreach (ModelMeshPart part in mesh.MeshParts) {
                        part.Effect = skyBoxEffect;
                    
                        part.Effect.Parameters["World"].SetValue(world);
                        part.Effect.Parameters["View"].SetValue(view);
                        part.Effect.Parameters["Projection"].SetValue(projection);
                        part.Effect.Parameters["SkyBoxTexture"].SetValue(cubeTexture);
                        part.Effect.Parameters["Camera"].SetValue(cameraPosition);
                    }
                mesh.Draw();
                }
            Vector3[] lightPosition = new Vector3[] { spheres[0].position, spheres[1].position, spheres[2].position};
            Vector4[] lightColor = new Vector4[] { spheres[0].color.ToVector4(), spheres[1].color.ToVector4(), spheres[2].color.ToVector4()};
            //for (int i = 0; i < cubes.Length; i++)
            
            foreach (Cube cube in cubes) {

                foreach (ModelMesh mesh in model.Meshes)
                {
                    foreach (ModelMeshPart part in mesh.MeshParts)
                    {
                        world = (Matrix.CreateScale(cube.scale) * Matrix.CreateTranslation(cube.position));
                        part.Effect = cubeEffect;
                        //part.Effect.Parameters["World"].SetValue(Matrix.CreateScale(10)*Matrix.CreateTranslation(cubes[i].position));
                        part.Effect.Parameters["World"].SetValue(world);
                        part.Effect.Parameters["View"].SetValue(view);
                        part.Effect.Parameters["Projection"].SetValue(projection);
                        part.Effect.Parameters["WorldInverseTranspose"].SetValue(Matrix.Transpose(Matrix.Invert(world)));
                        part.Effect.Parameters["Camera"].SetValue(cameraPosition);
                        part.Effect.Parameters["LightPosition"].SetValue(lightPosition);
                        part.Effect.Parameters["LightColor"].SetValue(lightColor);
                        part.Effect.Parameters["color"].SetValue(cube.color.ToVector4());
                    }
                    mesh.Draw();
                }
            }
            effect.EnableDefaultLighting();
            foreach (lightSpheres sphere in spheres) {
                foreach (ModelMesh mesh in ball.Meshes)
                {
                    foreach (ModelMeshPart part in mesh.MeshParts)
                    {
                        effect.LightingEnabled = true;
                        effect.SpecularColor = Vector3.Zero;
                        effect.DirectionalLight0.DiffuseColor = Vector3.Zero;
                        effect.DirectionalLight0.SpecularColor = Vector3.Zero;
                        effect.World = Matrix.CreateScale(10/3f)* Matrix.CreateTranslation(sphere.position);
                        effect.View = view;
                        effect.Projection = projection;
                        effect.EmissiveColor = sphere.color.ToVector3();
                        
                        part.Effect = effect;
                    }
                    mesh.Draw();
                }
            }
            

            // TODO: Add your drawing code here

            base.Draw(gameTime);
        }
        private float lightvalue(Random random)
        {
            float value = (float)random.NextDouble()*.5f+.5f;
            return value;

        }
        private Cube CubeSetter()
        {
            var random = new Random();
            float r = (float)random.NextDouble();
            float g = (float)random.NextDouble();
            float b = (float)random.NextDouble();
            Color color = new Color(r, g, b);
            r = (float)random.NextDouble() * 180 - 90;
            g = (float)random.NextDouble() * 180 - 90;
            b = (float)random.NextDouble() * 180 - 90;
            Vector3 position = new Vector3(r, g, b);
            //cubes.scale = scale;
            r = (float)random.NextDouble() * 2 - 1;
            g = (float)random.NextDouble() * 2 - 1;
            b = (float)random.NextDouble() * 2 - 1;
            // * ((float)random.NextDouble() * 5 + 5)
            Vector3 velocity = new Vector3(r, b, g);
            velocity.Normalize();
            velocity = velocity * new Vector3(((float)random.NextDouble() * 5 + 5), ((float)random.NextDouble() * 5 + 5),
                ((float)random.NextDouble() * 5 + 5));
            float scale = (float)random.NextDouble() * 8 + 2;
            Cube cube = new Cube(color, position, scale, velocity);
            return cube;

        }

        

        private lightSpheres SphereSetter()
        {
            var random = new Random();
            float r = lightvalue(random);
            float g = lightvalue(random);
            float b = lightvalue(random);
            Color color = new Color(r, g, b);
            r = (float)random.NextDouble() * 180 - 90;
            g = (float)random.NextDouble() * 180 - 90;
            b = (float)random.NextDouble() * 180 - 90;
            Vector3 position = new Vector3( r,g,b);
            //cubes.scale = scale;
            r = (float)random.NextDouble() * 2 - 1;
            g = (float)random.NextDouble() * 2 - 1;
            b = (float)random.NextDouble() * 2 - 1;
            // * ((float)random.NextDouble() * 5 + 5)
            Vector3 velocity = new Vector3(r, b, g);
            velocity.Normalize();
            velocity = velocity*((float)random.NextDouble() * 5 + 5);

            lightSpheres spheres = new lightSpheres( position, velocity, color);

            return spheres;

        }
    }

}